%% Euler Methods

%DE:= y'(t)+4*y(t)=2*exp(-5*t)

%Exact solution found using Matlab: y(t)=-2*exp(-5*t)+3*exp(-4*t)
    %Used initial condition of y(0)=1

%=========================================
%% Forward Euler Method for 1st Order ODE
%=========================================

h=0.1;		%h is the step size
t=0:h:2.5;	%initialize time array

clear ystar;	

ystar(1)=1.0;	%initial condition

for i=1:length(t)-1,
   k=2*exp(-5*t(i))-4*ystar(i);	%Calculates derivative at t(i)
   ystar(i+1)=ystar(i)+h*k;		%Estimates new value of y;
end

%exact solution
y=-2*exp(-5*t)+3*exp(-4*t);

%Plot approximate and exact solution.
subplot(3,1,1)
plot(t,ystar,'b--',t,y,'r-');
legend('Approximate','Exact');
title('Forward Euler Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');

clear all;

%===========================================
%% Modified Euler Method for 1st Order ODE
%===========================================

h=0.1;		%h is the step size
t=0:h:2.5;	%initialize time array

clear ystar;	

ystar(1)=1.0;	%initial condition

for i=1:length(t)-1,
   ynew=ystar(i)+h*(2*exp(-5*t(i))-4*ystar(i))
   k=2*exp(-5*t(i+1))-4*ynew
   ystar(i+1)=ystar(i)+h/2*((2*exp(-5*t(i))-4*ystar(i))+k);		%Estimates new value of y;
end

%exact solution
y=-2*exp(-5*t)+3*exp(-4*t);

%Plot approximate and exact solution.
subplot(3,1,2)
plot(t,ystar,'b--',t,y,'r-');
legend('Approximate','Exact');
title('Modified Euler Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');

clear all;

%=======================================
%Backward Euler Method for 1st Order ODE
%=======================================

h=0.1;		%h is the step size
t=0:h:2.5;	%initialize time array

clear ystar;	

ystar(1)=1.0;	%initial condition

for i=1:length(t)-1,
   ynew=ystar(i)+h*(2*exp(-5*t(i))-4*ystar(i))
   k=2*exp(-5*t(i+1))-4*ynew
   ystar(i+1)=ystar(i)+h*(k);		%Estimates new value of y;
end

%exact solution
y=-2*exp(-5*t)+3*exp(-4*t);

%Plot approximate and exact solution.
subplot(3,1,3)
plot(t,ystar,'b--',t,y,'r-');
legend('Approximate','Exact');
title('Backward Euler Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');