%==============
%% ODE45 Method
%==============

clear all;
h=0.1 %set initial step size
tspan=95:h:120;
xinit=1;
[t,x] = ode45(@n, tspan, xinit) %DE is -4*y+2*exp(-5*t);

yact=-2*exp(-5*t)+3*exp(-4*t); %exact solution

plot(t,yact,'r-',t,x,'b-.');
legend('Exact','Approximate');
title('ODE45 Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');

err(x,yact) %error between method and exact solution