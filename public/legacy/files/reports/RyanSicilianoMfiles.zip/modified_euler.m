%Modified Euler Method for 1st Order ODE

%y'(t)+4*y(t)=2*exp(-5*t)

%Exact solution found using Maple: y(t)=-2*exp(-5*t)+3*exp(-4*t)
    %Used initial condition of y(0)=1

h=0.1;		%h is the step size
t=0:h:4;	%initialize time array

clear ystar;	

ystar(1)=1.0;	%initial condition

for i=1:length(t)-1,
   ynew=ystar(i)+h*(2*exp(-5*t(i))-4*ystar(i))
   k=2*exp(-5*t(i+1))-4*ynew
   ystar(i+1)=ystar(i)+h/2*((2*exp(-5*t(i))-4*ystar(i))+k);		%Estimates new value of y;
end

%exact solution
y=-2*exp(-5*t)+3*exp(-4*t);

%Plot approximate and exact solution.
plot(t,ystar,'b--',t,y,'r-');
legend('Approximate','Exact');
title('Euler Approximation, h=0.01');
xlabel('Time');
ylabel('y*(t), y(t)');

err(ystar,y)
