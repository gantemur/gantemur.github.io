%====================
%% Runge-Kutta Method
%====================

%DE:= y'(t)+4*y(t)=2*exp(-5*t)

%Exact solution found using Maple: y(t)=-2*exp(-5*t)+3*exp(-4*t)
    %Used initial condition of y(0)=1

h=0.1;		%h is the step size
t=0:h:2.5;	%initialize time array

clear ystar;	

ystar(1)=1.0;	%initial condition

for i = 1:length(t)-1
	k1 = 2*exp(-5*t(i))-4*ystar(i);
    k2 = 2*exp(-5*(t(i)+h/2))-4*(ystar(i)+(h/2)*k1);
	k3 = 2*exp(-5*(t(i)+h/2))-4*(ystar(i)+(h/2)*k2);
	k4 = 2*exp(-5*(t(i)+h))-4*(ystar(i)+(h)*k3);
	ystar(i+1) = ystar(i) + h/6*(k1 + 2*k2 + 2*k3 + k4);
end

%exact solution
y=-2*exp(-5*t)+3*exp(-4*t);

plot(t,y,'r-',t,ystar,'b-.');
legend('Exact','Approximate');
title('Runge-Kutta (4th Order) Approximation, h=0.1');
xlabel('Time');
ylabel('y*(t), y(t)');

err(ystar,y)