function [p]=percenterr(yact,ytheo)
for i=1:length(yact-1)
    per(i)=(ytheo(i)-yact(i))/yact(i);
end
p=mean(per)*100;