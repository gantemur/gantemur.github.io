clc %clears workspace
clear %clears any variables

%Model Constants:
Cm = 1.0; %(uF/cm^2) Membrane capacitance
ENa = 50; %(mV) Sodium Voltage
EK = -77; %(mV) Potassium Voltage
EL = -54.4; %(mV) Leakage Voltage
gbarNa = 120; %(mS/cm^2) Sodium conductance
gbarL = 0.3; %(mS/cm^2) Leakage conductance
gbarK = 36; %(mS/cm^2) Potassium conductance

V(1)=-65;
m(1)=am(V(1))/(am(V(1))+bm(V(1)));
n(1)=an(V(1))/(an(V(1))+bn(V(1)));
h(1)=ah(V(1))/(ah(V(1))+bh(V(1)));

step=0.01;
t=0:0.01:100

for i = 1:length(t)-1
    m(i+1)=m(i)+step*((am(V(i))*(1-m(i)))-(bm(V(i))*m(i)));
    n(i+1)=n(i)+step*((an(V(i))*(1-n(i)))-(bn(V(i))*n(i)));
    h(i+1)=h(i)+step*((ah(V(i))*(1-h(i)))-(bh(V(i))*h(i)));
    V(i+1)=V(i)+step*((1/Cm)*(-(gbarK*n(i)^4*(V(1)-EK))-(gbarNa*m(i)^3*h(i)*(V(1)-ENa))-(gbarL*(V(1)-EL))));
end
plot(t,V);