

clear all;
h=0.1
tspan=0:h:2;
xinit=1;	%initial condition
y=-2*exp(-5*tspan)+3*exp(-4*tspan); %exact solution

for j=1:10;		%h is the step size
    harray(j)=h;
    h=h/2;
    clear tspan;
    tspan=0:h:2;
    clear x; clear t;
    [t,x] = ode45(@DE, tspan, xinit);
    y=-2*exp(-5*tspan)+3*exp(-4*tspan);
    p(j)=err(x,y)
end

loglog(harray,p)
title('ODE45 Method - Step Size vs. Error');
xlabel('Step Size (h)');
ylabel('Error');