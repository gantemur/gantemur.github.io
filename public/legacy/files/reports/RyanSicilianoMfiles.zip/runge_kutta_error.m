%% Error for Forward Euler Method

clear all;
h=0.1
t=0:h:2;
ystar(1)=1.0;	%initial condition
y=-2*exp(-5*t)+3*exp(-4*t); %exact solution

for j=1:10;		%h is the step size
    harray(j)=h;
    h=h/2;
    t=0:h:2;
    clear ystar;
    ystar(1)=1;
    y=-2*exp(-5*t)+3*exp(-4*t);
    for i = 1:length(t)-1
        k1 = 2*exp(-5*t(i))-4*ystar(i);
        k2 = 2*exp(-5*(t(i)+h/2))-4*(ystar(i)+(h/2)*k1);
        k3 = 2*exp(-5*(t(i)+h/2))-4*(ystar(i)+(h/2)*k2);
        k4 = 2*exp(-5*(t(i)+h))-4*(ystar(i)+(h)*k3);
        ystar(i+1) = ystar(i) + h/6*(k1 + 2*k2 + 2*k3 + k4);
    end
    p(j)=err(ystar,y)
end

loglog(harray,p)
title('Runge-Kutta Method - Step Size vs. Error');
xlabel('Step Size (h)');
ylabel('Error');
