%% Error for Backward Euler Method

clear all;
h=0.1
t=0:h:2;
ystar(1)=1.0;	%initial condition
y=-2*exp(-5*t)+3*exp(-4*t); %exact solution

for j=1:10;		%h is the step size
    harray(j)=h;
    h=h/2;    
    t=0:h:2;
    clear ystar;
    ystar(1)=1;
    y=-2*exp(-5*t)+3*exp(-4*t);
    for i=1:length(t)-1,
   ynew=ystar(i)+h*(2*exp(-5*t(i))-4*ystar(i));
   ystar(i+1)=ystar(i)+h*(2*exp(-5*t(i+1))-4*ynew);		%Estimates new value of y;
end
    p(j)=err(ystar,y)
end

loglog(harray,p)
title('Backward Euler Method - Step Size vs. Error');
xlabel('Step Size (h)');
ylabel('Error');